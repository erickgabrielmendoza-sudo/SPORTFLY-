
import React, { useState } from 'react';
import { TravelPackage, UserProfile } from '../types';
import { COMMISSION_FEE_MXN } from '../constants';

interface BookingSummaryProps {
  pkg: TravelPackage;
  user: UserProfile;
  onClose: () => void;
  onConfirmPurchase?: (pkg: TravelPackage, totalSaved: number) => void;
}

const BookingSummary: React.FC<BookingSummaryProps> = ({ pkg, user, onClose, onConfirmPurchase }) => {
  const [view, setView] = useState<'summary' | 'payment' | 'success'>('summary');
  const [quantity, setQuantity] = useState(1);
  const [cardData, setCardData] = useState({ 
    number: '', 
    expiry: '', 
    cvv: '', 
    name: '',
    email: user.email || '' 
  });
  
  const hotelTotal = pkg.hotel ? (pkg.hotel.pricePerNight * (pkg.totalDays - 1 || 1)) : 0;
  const premiumFlightDiscountUnit = user.isPremium ? (pkg.flight.price * 0.1) : 0;
  const unitCommission = user.isPremium ? 0 : COMMISSION_FEE_MXN;
  
  const unitTotal = pkg.event.ticketPrice + (pkg.flight.price - premiumFlightDiscountUnit) + hotelTotal + unitCommission;
  
  const isBulkDiscountEligible = quantity > 3;
  const bulkDiscountPercent = isBulkDiscountEligible ? 0.25 : 0;
  const totalBeforeBulk = unitTotal * quantity;
  const bulkDiscountAmount = totalBeforeBulk * bulkDiscountPercent;
  const finalTotal = totalBeforeBulk - bulkDiscountAmount;

  const totalSavingsGenerated = ((user.isPremium ? COMMISSION_FEE_MXN : 0) + premiumFlightDiscountUnit) * quantity + bulkDiscountAmount;

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    if (onConfirmPurchase) onConfirmPurchase(pkg, totalSavingsGenerated);
    setView('success');
  };

  if (view === 'success') {
    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
        <div className="bg-white rounded-[40px] w-full max-w-2xl p-8 md:p-12 my-8 text-center shadow-2xl animate-in zoom-in duration-300">
           <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
             <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
           </div>
           <h2 className="text-3xl font-sport text-blue-900 mb-2">¡Sincronización Exitosa!</h2>
           <p className="text-gray-500 mb-8">Tus accesos están listos en la sección de Mis Viajes.</p>
           
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10 text-left">
              <div className="bg-slate-50 border-2 border-dashed border-gray-200 rounded-[32px] p-6">
                <p className="text-[10px] font-black text-blue-900 uppercase tracking-widest mb-4">E-Ticket Estadio</p>
                <img src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=STADIUM-${pkg.event.id}`} alt="QR" className="mx-auto w-40 h-40 bg-white p-2 rounded-xl mb-4 shadow-sm" />
                <p className="font-bold text-xs text-center text-blue-900">{pkg.event.name}</p>
              </div>
              <div className="bg-blue-900 border-2 border-dashed border-blue-800 rounded-[32px] p-6">
                <p className="text-[10px] font-black text-blue-200 uppercase tracking-widest mb-4">Pase de Abordar {pkg.flight.airline}</p>
                <img src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=FLIGHT-${pkg.flight.airline}&color=1e3a8a`} alt="QR" className="mx-auto w-40 h-40 bg-white p-2 rounded-xl mb-4 shadow-sm" />
                <p className="font-bold text-xs text-center text-white">{pkg.flight.isRoundTrip ? 'IDA Y VUELTA' : 'SÓLO IDA'}</p>
              </div>
           </div>

           <button onClick={onClose} className="w-full bg-blue-900 text-white py-5 rounded-3xl font-bold uppercase tracking-widest shadow-xl">Cerrar y Ver Wallet</button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-[40px] w-full max-w-lg overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-300 my-8">
        <div className="bg-blue-900 p-8 text-white relative">
          <button onClick={onClose} className="absolute top-6 right-6 hover:bg-blue-800 p-2 rounded-full">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-amber-400 text-blue-900 text-[8px] font-black px-2 py-0.5 rounded-md uppercase">Cifrado 256-bit</span>
          </div>
          <h2 className="text-3xl font-sport">
            {pkg.packageType === 'Full' ? 'COMBO FULL' : 'PACK VUELO'}
          </h2>
        </div>

        <div className="p-8">
          {view === 'summary' ? (
            <>
              <div className="mb-6 p-4 bg-slate-50 rounded-2xl flex justify-between items-center border border-gray-100">
                <label className="text-xs font-black text-gray-500 uppercase tracking-widest">Pasajeros</label>
                <div className="flex items-center gap-4">
                  <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center font-bold text-blue-900 hover:bg-white">-</button>
                  <span className="font-sport text-lg">{quantity}</span>
                  <button onClick={() => setQuantity(quantity + 1)} className="w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center font-bold text-blue-900 hover:bg-white">+</button>
                </div>
              </div>

              <div className="space-y-3 mb-8">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400 font-bold">Boleto Estadio (x{quantity})</span>
                  <span className="font-black text-blue-900">${(pkg.event.ticketPrice * quantity).toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400 font-bold">Vuelo {pkg.flight.isRoundTrip ? 'Redondo' : 'Sencillo'} (x{quantity})</span>
                  <span className="font-black text-blue-900">${((pkg.flight.price - premiumFlightDiscountUnit) * quantity).toLocaleString()}</span>
                </div>
                {pkg.hotel && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400 font-bold">Hotel Sincronizado</span>
                    <span className="font-black text-blue-900">${(hotelTotal * quantity).toLocaleString()}</span>
                  </div>
                )}
                
                {/* Desglose de Comisión de 560 MXN por paquete */}
                <div className="flex justify-between text-sm pt-3 border-t border-gray-50">
                  <div className="flex items-center gap-1.5">
                    <span className="text-gray-400 font-bold uppercase text-[10px] tracking-widest">Cargo Sportfly Logística</span>
                    <span className="w-3 h-3 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-[7px] font-bold cursor-help" title="Costo por sincronización segura de boletos y vuelos">?</span>
                  </div>
                  <div className="text-right">
                    {user.isPremium ? (
                      <span className="text-green-600 font-black text-[10px]">INCLUIDO ELITE</span>
                    ) : (
                      <span className="font-black text-blue-900">${(COMMISSION_FEE_MXN * quantity).toLocaleString()}</span>
                    )}
                  </div>
                </div>
              </div>

              <div className="bg-blue-900 p-6 rounded-3xl text-white mb-6">
                 <div className="flex justify-between items-end">
                    <div>
                      <p className="text-[10px] font-black text-blue-300 uppercase tracking-widest mb-1">Total Sincronizado</p>
                      <p className="text-4xl font-sport leading-none">${finalTotal.toLocaleString()}</p>
                    </div>
                    <div className="text-right">
                       <p className="text-[10px] font-black text-green-400 uppercase">Sin Cargos Ocultos</p>
                    </div>
                 </div>
              </div>

              <button onClick={() => setView('payment')} className="w-full bg-blue-900 text-white py-5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-blue-950 transition-all active:scale-95">Continuar al Pago</button>
            </>
          ) : (
            <form onSubmit={handlePay} className="space-y-4">
               {/* Simulación de Formulario de Pago */}
               <div className="space-y-4">
                  <div className="p-4 bg-slate-50 rounded-2xl border border-gray-100">
                    <p className="text-[9px] font-black text-gray-400 uppercase mb-2">Tarjeta de Crédito / Débito</p>
                    <input type="text" placeholder="#### #### #### ####" className="w-full bg-transparent border-none outline-none font-bold text-blue-900 text-lg" required />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-slate-50 rounded-2xl border border-gray-100">
                      <p className="text-[9px] font-black text-gray-400 uppercase mb-2">Expira</p>
                      <input type="text" placeholder="MM/YY" className="w-full bg-transparent border-none outline-none font-bold text-blue-900" required />
                    </div>
                    <div className="p-4 bg-slate-50 rounded-2xl border border-gray-100">
                      <p className="text-[9px] font-black text-gray-400 uppercase mb-2">CVV</p>
                      <input type="password" placeholder="***" className="w-full bg-transparent border-none outline-none font-bold text-blue-900" required />
                    </div>
                  </div>
               </div>
               <button type="submit" className="w-full bg-green-600 text-white py-5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl mt-4 hover:bg-green-700 transition-all">Pagar ${finalTotal.toLocaleString()}</button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default BookingSummary;
